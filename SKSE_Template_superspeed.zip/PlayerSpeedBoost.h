#pragma once

constexpr float DEFAULT_SPEED_BONUS = 500.0f;
